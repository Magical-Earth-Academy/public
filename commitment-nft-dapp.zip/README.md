# Commitment NFT Dapp

This project is a Proof-of-Value (PoV) system built on Ethereum (Sepolia Testnet). Contributors mint NFTs that contain a commitment, author name, and fair market value. NFTs can be swapped only when new contributions of equal or greater value are made.

## Project Structure

- **contracts/**: Solidity smart contracts
- **scripts/**: Hardhat deployment scripts
- **frontend/**: React-based dApp using ethers.js
- **.env**: Required for private key and Sepolia RPC

## Setup

```bash
git clone <repo>
cd commitment-nft-dapp
npm install
cp .env.example .env
# Fill in your PRIVATE_KEY and SEPOLIA_RPC
npx hardhat compile
npx hardhat run scripts/deploy.js --network sepolia
cd frontend
npm install
npm run dev
```
