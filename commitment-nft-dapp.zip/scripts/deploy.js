async function main() {
  const CommitmentNFT = await ethers.getContractFactory("CommitmentNFT");
  const commitmentNFT = await CommitmentNFT.deploy();
  await commitmentNFT.deployed();
  console.log(`Contract deployed to: ${commitmentNFT.address}`);
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
