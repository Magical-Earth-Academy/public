import { useState } from 'react';
import { ethers } from 'ethers';
import abi from '../abi/CommitmentNFT.json';
import './App.css';

const CONTRACT_ADDRESS = "PASTE_DEPLOYED_CONTRACT_ADDRESS_HERE";

function App() {
  const [commitment, setCommitment] = useState('');
  const [author, setAuthor] = useState('');
  const [value, setValue] = useState('');
  const [status, setStatus] = useState('');
  const [account, setAccount] = useState(null);
  const [swapTokenId, setSwapTokenId] = useState('');

  const connectWallet = async () => {
    if (window.ethereum) {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      setAccount(accounts[0]);
    }
  };

  const mintNFT = async () => {
    if (!window.ethereum) return alert("Install MetaMask");
    setStatus("Minting...");
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(CONTRACT_ADDRESS, abi.abi, signer);
    try {
      const tx = await contract.mintCommitmentNFT(commitment, author, ethers.utils.parseEther(value));
      await tx.wait();
      setStatus("NFT minted successfully.");
    } catch (error) {
      setStatus(`Error: ${error.message}`);
    }
  };

  const swapNFT = async () => {
    setStatus("Swapping...");
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(CONTRACT_ADDRESS, abi.abi, signer);
    try {
      const tx = await contract.swapCommitment(
        swapTokenId,
        commitment,
        author,
        ethers.utils.parseEther(value)
      );
      await tx.wait();
      setStatus("NFT swapped successfully.");
    } catch (error) {
      setStatus(`Error: ${error.message}`);
    }
  };

  return (
    <div className="app">
      <h1>Commitment NFT Dapp</h1>
      <button onClick={connectWallet}>
        {account ? `Connected: ${account}` : 'Connect Wallet'}
      </button>
      <input
        placeholder="Author"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
      />
      <textarea
        placeholder="Describe your commitment"
        value={commitment}
        onChange={(e) => setCommitment(e.target.value)}
      />
      <input
        placeholder="Fair Market Value (ETH)"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        type="number"
      />
      <button onClick={mintNFT}>Mint NFT</button>

      <h2>Or Swap</h2>
      <input
        placeholder="Token ID to Acquire"
        value={swapTokenId}
        onChange={(e) => setSwapTokenId(e.target.value)}
      />
      <button onClick={swapNFT}>Swap NFT</button>

      <p>Status: {status}</p>
    </div>
  );
}

export default App;
